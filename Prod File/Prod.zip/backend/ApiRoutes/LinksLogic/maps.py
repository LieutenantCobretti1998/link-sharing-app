background_images = {
    "sunshine": "../../images/background-images/pexels-chinar-minar-1265133847-25724597.jpg",
    "birds in dance": "../../images/background-images/boston-public-library-YoK5pBcSY8s-unsplash.jpg",
    "creative": "../../images/background-images/pexels-ann-h-45017-1762851.jpg",
    "infinite-stairs": "../../images/background-images/pexels-mithulvarshan-3023211.jpg",
}